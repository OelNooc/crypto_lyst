package cl.nooc.cryptolyst.modelo

data class Coins(
    val `data`: List<CoinData>
)